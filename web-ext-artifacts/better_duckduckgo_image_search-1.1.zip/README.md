# Better DDG Image Search

DuckDuckGo images are too small on their search gallery. This makes them bigger.

## Before

![before](/img/before.png)

## After

![after](/img/after.png)

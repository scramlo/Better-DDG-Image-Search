# Better DDG Image Search

DuckDuckGo images are too small on their search gallery. This makes them bigger.
